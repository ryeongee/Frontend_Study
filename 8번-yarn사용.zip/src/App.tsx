import React from "react";
import TodoApp from './containers/TodoApp'

const App: React.FC = () => {
  return <TodoApp />;
};

export default App;
