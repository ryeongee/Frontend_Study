export { default } from "./reducer"; // reducer 를 불러와서 default로 내보내겠다는 의미
export * from "./actions"; // 모든 액션 생성함수들을 불러와서 같은 이름들로 내보내겠다는 의미
export * from "./types"; // 모든 타입들을 불러와서 같은 이름들로 내보내겠다는 의미

//  덕스 타입은 리듀서만 디폴트로 내보냄
